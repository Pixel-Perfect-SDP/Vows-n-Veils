exports.getExample = (req, res) => {
  res.json({ message: 'Hello from the backend!' });
};

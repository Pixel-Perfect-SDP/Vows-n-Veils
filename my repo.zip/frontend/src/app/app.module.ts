// No longer needed for standalone bootstrap.
// You can delete this file.